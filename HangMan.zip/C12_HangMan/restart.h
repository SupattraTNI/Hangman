#ifndef RESTART_H
#define RESTART_H

#include <iostream>

using namespace std;

bool restart();

#endif


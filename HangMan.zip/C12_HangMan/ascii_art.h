#ifndef RESTART_H
#define RESTART_H

#include <iostream>
#include <string>

using namespace std;

void ascii_art(string);

#endif



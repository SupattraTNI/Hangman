#ifndef VOCAB_H
#define VOCAB_H

#include <iostream>
#include <string>

using namespace std;

class vocab{
public:
    string animal[10] = {};
    string classroom[10] = {};
    void readVocab();

};

#endif

